require 'filesystem'

return fs.current_path():parent_path()
