return {
    old_reader = require 'ui-builder.old-reader',
    new_reader = require 'ui-builder.new-reader',
    old_writer = require 'ui-builder.old-writer',
    new_writer = require 'ui-builder.new-writer',
    merge = require 'ui-builder.merge',
}
