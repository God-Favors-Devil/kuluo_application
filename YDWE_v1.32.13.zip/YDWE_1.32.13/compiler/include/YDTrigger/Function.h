# /*
#  *  YDTrigger专用宏
#  * 
#  *  函数部分
#  * 
#  *  By actboy168
#  *
#  */
#
#ifndef INCLUDE_FUNCTION_H
#define INCLUDE_FUNCTION_H
#
#endif
