local convert = require 'backend.convert'

return function()
    convert('lni')
end
